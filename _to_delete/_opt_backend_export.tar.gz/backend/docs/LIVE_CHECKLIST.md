# Live Trading Checklist — Post-Change Verification

Run through this checklist after every code change before going live.

---

## 1. Signal Panel Accuracy

- [ ] Active strategy panel shows correct signal (not stale HOLD when signal exists on chart)
- [ ] Secondary strategy panel shows correct signal (same check)
- [ ] When signal fires: panel shows SHORT (active) or LONG (active) in correct color (red/green, not yellow HOLD)
- [ ] Entry / SL / T1 / T2 values displayed and match the signal data
- [ ] When EXIT fires (SL hit, T1/T2 hit, strategy exit): panel clears back to current signal (HOLD)
- [ ] Strategy Reasons expandable and populated

## 2. Signal Deduplication

- [ ] Same-direction signal on consecutive bars: logged only ONCE (not 5x M:S markers)
- [ ] Different direction (SHORT to LONG): new signal logged correctly
- [ ] Different instrument same direction: logged independently
- [ ] Different strategy same direction: logged independently
- [ ] Chart markers match signal_history count (1 marker per logged signal)

## 3. Instrument Isolation (test all 4: NIFTY, BANKNIFTY, SENSEX, CRUDEOIL)

- [ ] Switching instrument clears: signal panel, chart markers, signal history display
- [ ] Signal history API returns only current instrument signals
- [ ] Signal journal filtered by current instrument
- [ ] _live_frames cache invalidated on instrument switch (no stale data from previous instrument)
- [ ] LTP displays correctly for MCX instruments (uses futures contract, not bare index name)
- [ ] No "Enter valid Script Name" errors in console for any instrument

## 4. Strategy Separation

- [ ] Changing Multi-Agent parameters does NOT affect Regime T/R signals
- [ ] Changing Regime parameters does NOT affect Multi-Agent signals
- [ ] Both strategies evaluate independently every poll cycle
- [ ] Each strategy signals tagged with correct strategy field in logs
- [ ] Switching active strategy clears signal panel and chart markers

## 5. Auto-Trade Safety

- [ ] Auto-trade only executes for the ACTIVE strategy (not secondary)
- [ ] Auto-trade only acts on configured instrument
- [ ] Same signal fired multiple times: only ONE trade opened (dedup prevents re-entry)
- [ ] SL/T1/T2 hit: position closed, exit logged, panel clears
- [ ] Opposite signal: existing position closed first, then new entry

## 6. Chart Markers

- [ ] R:S / R:L = Regime SHORT/LONG entry
- [ ] R:X = Regime exit
- [ ] M:S / M:L = Multi-Agent SHORT/LONG entry
- [ ] M:X = Multi-Agent exit
- [ ] Markers from BOTH strategies visible regardless of which is active
- [ ] No duplicate markers for same signal
- [ ] Markers cleared when switching instrument

## 7. Data Pipeline

- [ ] Historical data fetches correct instrument from Dhan API
- [ ] MCX uses exchange=MCX, NSE uses exchange=INDEX
- [ ] All timeframes (1m, 5m, 15m, 60m, 1D) loading for current instrument
- [ ] Data staleness detection working

## 8. IST Timezone — All Dates/Times Must Be IST (Never UTC in UI/Logs)

- [ ] Signal history `recorded_at` uses `datetime.now(_IST)` — in `_add_signal_to_history()`
- [ ] Chart candle timestamps: broker returns naive-UTC, main.py adds +19800 offset for IST chart display
- [ ] Telegram alerts show IST time (`datetime.now(_IST).strftime('%H:%M:%S') IST`) — both entry and exit
- [ ] Trade journal entry_time and exit_time: uses `datetime.now(_IST)` — in journal_manager.py
- [ ] Signal journal: entry/exit times from signal dict `time` field (IST isoformat from strategy)
- [ ] Auto-trade execution: order IDs use IST timestamps (PAPER_ and TEST_LIVE_ prefixes)
- [ ] Trade manager: `entry_time = datetime.now(_IST).isoformat()`
- [ ] Slippage tracker: `datetime.now(_IST)` for entry/exit fill logging
- [ ] Performance tracker: uses `_IST` timezone
- [ ] ML training: status timestamps use `_IST`
- [ ] WebSocket heartbeat: `datetime.now(_IST).isoformat()`
- [ ] Market hours check in polling loop: `datetime.now(pytz.timezone("Asia/Kolkata"))`
- [ ] Strategy signal `time` field: converted from UTC to `Asia/Kolkata` isoformat — in orchestrator.py and regime_orchestrator.py
- [ ] Backtest trade times: `tz_localize("UTC").tz_convert("Asia/Kolkata")` — in both strategy.py and regime_strategy.py

**Internal pipeline convention (correct by design):**
Broker returns naive-UTC timestamps → strategy.py stores internally as naive-UTC → converts to IST only at output boundaries (chart display, signal time, trade log).

## 9. Backtest ↔ Live Data Pipeline Parity

Both systems MUST produce identical signals for the same data:

- [ ] **Same data source**: Both use `broker.get_historical_data()` via Dhan API → same OHLCV
- [ ] **Same indicator computation**: Both call `strategy.add_indicators()` (shared function)
- [ ] **Same merged table**: Both call `strategy.build_merged_table()` with identical logic
- [ ] **Same session filter**: Both use `_session_mask()` with identical IST-based instrument-aware windows
- [ ] **Same agent pipeline**: Both run identical agent singletons (Macro → Structure → Momentum → Trigger → Volume → Memory → Orchestrator)
- [ ] **Regime strategy**: `regime_strategy.py` calls `main_strategy.build_merged_table()` — shares exact data prep
- [ ] **Completed candle guard**: Live uses `now_utc >= candidate_time + timedelta(minutes=5)` to skip forming candle. Backtest processes all bars sequentially (already closed). Equivalent — no repainting.

**Data pipeline flow (identical path):**
```
Dhan API → broker.get_historical_data() [naive-UTC timestamps]
  → add_indicators() per timeframe
  → build_merged_table() [asof merge all TFs]
  → _session_mask() [IST trading window filter]
  → agent evaluation on latest completed bar
```

## 10. Auto-Trade & Telegram — Same Pipeline & IST

- [ ] Auto-trade signal comes from `_all_strat_sigs[cfg.strategy]` — same signal driving chart markers and panel
- [ ] Auto-trade uses same `frames` dict from `_fetch_all_frames()` — same data as live signal display
- [ ] Telegram entry alert: triggered AFTER order execution, uses same `sig` dict (entry/SL/T1/T2)
- [ ] Telegram exit alert: triggered AFTER position close, uses IST timestamps throughout
- [ ] Telegram timestamps: `datetime.now(_IST).strftime('%H:%M:%S') IST`
- [ ] 2-poll confirmation: signal must persist across 2 consecutive 60s polls before execution
- [ ] Auto square-off: uses IST market hours (`MARKET_HOURS`) for close-time calculation

## 11. Repainting Analysis — Both Strategies

**Neither strategy repaints.** Verified:

### Multi-Agent Strategy (strategy.py)
- [ ] **Completed candle only**: Live uses `now_utc >= candidate_time + timedelta(minutes=5)` — skips forming 5m bar
- [ ] **Indicators non-repainting**: SuperTrend, EMA, MACD, StochRSI, ATR — all on closed bars
- [ ] **Trendlines**: `shift(swing_order)` delays swing confirmation — no lookahead
- [ ] **Behavioral features**: Computed on merged table with closed-bar data only
- [ ] **ML model**: Scores on latest completed bar features — no future data
- [ ] **Pattern memory (FAISS)**: Trained on historical outcomes, queries current bar — no lookahead

### Regime Trend/Range Strategy (regime_strategy.py)
- [ ] **Completed candle only**: Same `now_utc >= candidate_time + timedelta(minutes=5)` guard
- [ ] **Regime detection**: Uses lookback of 15 bars before current — no lookahead
- [ ] **Swing structure**: `swing_order=3` means confirmation 3 bars later — no lookahead
- [ ] **HTF data in backtest**: Sliced with `df_1h["timestamp"] <= cur_ts` — prevents future HTF data leak
- [ ] **Trailing SL in backtest**: Uses only current bar high/low/close and historical extreme — no future reference

**Subtle nuance (by design, not a bug):**
HTF indicators (1H EMA, daily SuperTrend) merged via `merge_asof(direction="backward")` — each 5m bar sees latest *completed* higher-TF bar. In live, current 1H bar may still be forming — merge_asof picks previous completed 1H bar. Backtest: same behavior. **No repainting.**

## 12. Backtest vs Live Result Differences — What to Expect

| Factor | Backtest | Live | Impact |
|--------|----------|------|--------|
| **Execution price** | Exact signal price (bar close) | Market order + slippage (1-5 pts) | Live PnL slightly worse |
| **SL/T1/T2 hit** | Intra-bar: checks high/low | LTP poll every 60s may miss exact touch | Live may miss by 1 bar |
| **Data completeness** | All bars present | Possible gaps from API issues | May skip a signal |
| **2-poll confirmation** | Not used (immediate) | Must persist 2 consecutive polls | Filters ~30% transient signals |
| **Trailing SL update** | Every bar (5 min) | Every poll (60 sec) | Live MORE responsive (12x/bar) |
| **EOD exit** | 3:10 PM IST (Regime) | Auto square-off configurable | Minor timing diff |
| **ML model** | Static from training date | Same static model | Identical |
| **Pattern memory** | Same FAISS index | Same FAISS index | Identical |
| **Position sizing** | Fixed lot × multiplier | Same (broker may adjust margin) | Usually identical |
| **Opposite signal** | Exit only, no auto-flip | Same logic | Identical |

**Bottom line:** Expect ~85-90% of backtest trades to appear in live with similar direction/timing. PnL per trade differs by slippage (Rs.50-200/trade for BANKNIFTY). Win rate should be similar. The 2-poll confirmation is the biggest filter — prevents some good AND bad entries.

---

## Known Edge Cases

1. **Sticky panel in manual mode**: If no position opened (auto-trade OFF), panel shows "SHORT (active)" until strategy fires a different direction. This is correct — shows last recommendation.

2. **Shared data utilities**: regime_strategy.py imports build_merged_table and add_indicators from strategy.py. These are data-prep functions, not strategy logic. A change to these functions could affect both strategies.

3. **Exit signal strategy tagging**: Position management exits (SL/T1/T2 hit) default to cfg.strategy (active strategy) for the strategy tag. The non-active strategy sticky panel clears independently when that strategy's own evaluation produces an EXIT or direction change.

4. **MCX lot size**: Dhan API may fail to resolve MCX futures lot size — falls back to hardcoded value (10). The "Enter valid Script Name" warning is from Tradehull library, not a crash.

5. **2-poll confirmation timing**: If market moves fast and signal only fires on one bar (next bar reverts), live will NOT enter. Backtest would have entered. This is a safety feature, not a bug.

6. **Trailing SL live vs backtest granularity**: Live updates trailing SL every 60s poll, backtest only at 5m bar boundaries. Live may exit slightly earlier or later than backtest shows.
